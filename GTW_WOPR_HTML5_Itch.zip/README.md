# W.O.P.R. // Global Thermonuclear War (NORAD 1983 Strategic Simulator)

An authentic 1983 **WarGames** WOPR (*War Operation Plan Response*) and **NORAD Cheyenne Mountain Strategic Simulator**, available as both a standalone native Windows Desktop application (`GTW_WOPR.exe` for Steam) and a zero-dependency offline HTML5/Canvas vector simulator.

---

## Key Features

### Phase 1: IMSAI 8080 Dial-In & Joshua Terminal (`LOGON:`)
- **Sunnyvale War-Dialer (`311-555-4855`)**: Scan Sunnyvale, CA modem lines with procedural **DTMF dial tones** and authentic **300-baud Bell 103 acoustic coupler carrier handshakes**.
- **Authentic 1983 *WarGames* Dialogue**:
  - `"GREETINGS PROFESSOR FALKEN."`
  - `"HOW ARE YOU FEELING TODAY?"`
  - `"SHALL WE PLAY A GAME?"`
  - Full 15-game WOPR catalog (`FALKEN'S MAZE`, `BLACK JACK`, `GIN RUMMY`, `HEARTS`, `BRIDGE`, `CHECKERS`, `CHESS`, `POKER`, `FIGHTER COMBAT`, `GUERRILLA ENGAGEMENT`, `DESERT WARFARE`, `AIR-TO-GROUND ACTIONS`, `THEATERWIDE TACTICAL WARFARE`, `THEATERWIDE BIOTOXIC AND CHEMICAL WARFARE`, `GLOBAL THERMONUCLEAR WAR`) plus the `"WOULDN'T YOU PREFER A GOOD GAME OF CHESS?"` Easter egg.
- **Side & 1983 War Plan Selection**:
  - Choose `1. UNITED STATES (NORAD / SAC)` or `2. SOVIET UNION (PVO / GENERAL STAFF)`.
  - 4 authentic 1983 War Plans:
    1. `SIOP-62 FULL RETALIATION`
    2. `NORTH ATLANTIC / GIUK GAP ESCALATION`
    3. `FIRST STRIKE DECAPITATION`
    4. `DEFCON 1 TOTAL EXCHANGE`

### Phase 2: NORAD Cheyenne Mountain Vector World Map ("The Big Board")
- **Dual Vector Projections**: Toggle between **NORAD Mercator** and **Arctic Polar Over-The-Pole** vector projections with accurate continental coastlines, Arctic Circle graticule, and rotating **BMEWS Early-Warning Radar Domes** (**Thule Greenland**, **Clear Alaska**, **Fylingdales UK**, **Pechora USSR**).
- **Illuminated DEFCON 5 → DEFCON 1 Tower**: Vertical Cheyenne Mountain status lamp tower with procedural WebAudio klaxon alarms.
- **Full Strategic Triad Forces**:
  1. **ICBM Silo Wings**: Malmstrom, Minot, F.E. Warren, Whiteman (Minuteman III / Peacekeeper MX) vs. Dombarovsky, Kozelsk, Kartaly, Uzhur (SS-18 Satan / SS-19 Stiletto).
  2. **Nuclear Ballistic Missile Submarines (SSBNs)**: Ohio-class Trident (`USS Ohio`, `USS Michigan`, `USS Florida`) vs. Typhoon / Delta-IV (`TK-208`, `TK-202`, `K-51`) patrolling stealthily until launch.
  3. **Strategic Bomber Wings & Interceptors**: B-52H Stratofortress & F-15 Eagle vs. Tu-95 Bear & Tu-160 Blackjack on fail-safe airborne alert orbits.
  4. **ABM / Air Defense Batteries**: Safeguard Sprint/Spartan & A-135 Moscow Galosh/Gazelle interceptors.
  5. **Reconnaissance & Early-Warning Satellites**: Orbiting DSP and Oko infrared satellites.
- **MIRV Bus Separation, EMP & Fallout Plumes**: Mid-course MIRV warhead bus splitting into multiple independent reentry vehicles, high-altitude EMP radar degradation, drifting radioactive fallout plumes, and a live **NORAD Battle Damage Assessment (BDA) Ticker**.

### Phase 3: `CPE 1704 TKS` Launch Code Lock & Tic-Tac-Toe (`0 PLAYERS`) Finale
- **WOPR Launch Code Tumbler (`[ C ] [ P ] [ E ] [ 1 ] [ 7 ] [ 0 ] [ 4 ] [ T ] [ K ] [ S ]`)**: Autonomous launch code decryption sequence with spinning alphanumeric characters and lock-in tones.
- **Tic-Tac-Toe (`NUMBER OF PLAYERS: 0`) Override**: Pit WOPR against itself at accelerating speed across 24 nuclear war scenarios (`WINNER: NONE`), culminating in CRT overload and Joshua's realization:
  - `"A STRANGE GAME."`
  - `"THE ONLY WINNING MOVE IS NOT TO PLAY."`
  - `"HOW ABOUT A NICE GAME OF CHESS?"`

---

## Running the Standalone Windows Desktop App (Steam Build)

```powershell
# Launch the compiled Win64 Desktop Application
.\dist\GTW_WOPR_Win64\GTW_WOPR.exe

# Rebuild from source (.NET 10 Windows Forms + WebView2)
dotnet publish .\desktop\GTW_WOPR.csproj -c Release -r win-x64 --self-contained false -o .\dist\GTW_WOPR_Win64

# Run automated verification suite
node .\tools\verify_gtw.mjs
```
